# SafeRent Miami

SafeRent Miami is a data-driven web application that helps users evaluate and compare neighborhoods in Miami-Dade based on affordability, safety, and livability using local open datasets.

## 🚀 Project Overview

- 🏠 Affordable Housing Inventory
- 🚔 Crime Data
- 📞 311 Service Requests
- 📊 Livability Scores (Planned Model)

## 📌 Week 1 Goals
- [x] Finalize project concept
- [x] Identify core datasets
- [x] Submit project proposal
- [x] Initialize GitHub repository

## 🧱 Tech Stack
- Frontend: React (fenago/fenago21 template)
- Backend: FastAPI (Python)
- Data Analysis: Pandas, Scikit-learn
- Deployment: Vercel (frontend), Render (backend)

## 📂 Folder Structure (starter plan)
```
/saferent-miami
├── /frontend/       # React app (customized from fenago21)
├── /backend/        # FastAPI backend + data model
├── /data/           # Raw + cleaned datasets
├── README.md
└── .gitignore
```
